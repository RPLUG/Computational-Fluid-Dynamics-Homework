#include "Helpfunc.h"
//#include <iostream>
using namespace std;
void Init_val_generate(MPI_Comm Comm2D,int* dim, int* Matrix_Size,
	double** MatrixA_StoreBuffer, double** MatrixB_StoreBuffer,int* Total_size) {
	int id;
	int Nproc;
	
	MPI_Comm_rank(Comm2D, &id);
	MPI_Comm_size(Comm2D, &Nproc);
	int coord[2];
	//��ȡÿ����ֿ�����꣬�Զ�ά���鷵��
	MPI_Cart_coords(Comm2D, id, 2, coord);
	//printf("Process %d from (%d,%d)\n", id, coord[0], coord[1]);
	if (id == 0) {
		if (Total_size[0] * Total_size[1] > 4E8) {
			printf("Matrix too Big!\n");
			fflush(stdout);
			MPI_Abort(Comm2D, CheckFasle);
		}
	}
	*MatrixA_StoreBuffer = (double*)malloc(sizeof(double) * Matrix_Size[0] * Matrix_Size[1]);
	*MatrixB_StoreBuffer = (double*)malloc(sizeof(double) * Matrix_Size[0] * Matrix_Size[1]);



	for (int i = 0; i < Matrix_Size[0]; i++) {
		for (int t = 0; t < Matrix_Size[1]; t++) {
			double x = ((double)coord[0] * Matrix_Size[0] + i - 1) / (Total_size[0] - 1);
			double y = ((double)coord[1] * Matrix_Size[1] + t - 1) / (Total_size[1] - 1);
			//A���� �� �棬ÿ��������ǰ�е����±�
			(*MatrixA_StoreBuffer)[i * Matrix_Size[0] + t] = exp(y) * sin(3.0 * x);
			//if (id == 3) { cout << (*MatrixA_StoreBuffer)[i * Matrix_Size[1] + t] << "    "; }
		}
		//cout << endl;
	}
	for (int j = 0; j < Matrix_Size[1]; j++) {
		for (int t = 0; t < Matrix_Size[0]; t++) {
			double x = ((double)coord[0] * Matrix_Size[0] + t - 1) / (Total_size[0] - 1);
			double y = ((double)coord[1] * Matrix_Size[1] + j - 1) / (Total_size[0] - 1);
			//B�����д�ţ�ÿ��������ǰ�����±�
			(*MatrixB_StoreBuffer)[j * Matrix_Size[1] + t] = (x + cos(4.0 * x)) * (1 + y);
			//if (id == 0) { cout << (*MatrixB_StoreBuffer)[j * Matrix_Size[1] + t] << "    "; }
		}
		//cout << endl;
	}
	//���ȷ�Ϸ����Ƿ���ȷ��������Ե�ʱ������һ�ξ�����
	//Init_Check(Comm2D, *MatrixA_StoreBuffer, *MatrixB_StoreBuffer,Matrix_Size, Total_size);
}

//������ʾ�ļ�麯��ֻ��������������ҵ�����ˣ����ģ�������㲻����ȫ�����һ��
void Init_Check(MPI_Comm Comm_World, double* MatrixA_StoreBuffer, double* MatrixB_StoreBuffer,
				int* Matrix_size, int* Total_Size)
{
	int Nproc;
	int id;
	int coord[2];
	MPI_Comm_rank(Comm_World, &id);
	MPI_Comm_size(Comm_World, &Nproc);
	MPI_Cart_coords(Comm_World, id, 2, coord);

	int position;
	int buffersize = 2 * sizeof(int) + sizeof(double) * 2 * Matrix_size[0] * Matrix_size[1];
	char* Buffer = (char*)malloc(sizeof(char) * buffersize);
	MPI_Status st;
	//��ʼ��ʽ��鲿�֣�0���̽��������������̵����ݣ������Լ��ڴ��еľ������Ѱַ�Ա�
	//������ֲ�һ�£����治һ�µ�λ��

	if (id == 0) {
		if (Total_Size[0] * Total_Size[1] > 1E8) {
			printf("Try to using smaller Matrix While execute Matrix check function 'Init_Check'");
			fflush(stdout);
			MPI_Abort(Comm_World, CheckFasle);
		}
		printf("Begin to check sub Matric on other processes, Please wait... \n");
		//A size must be same as B
		double** Single_StorageA = CreatSingleThreadToCheckA(Matrix_size, Total_Size);
		double** Single_StorageB = CreatSingleThreadToCheckB(Matrix_size, Total_Size);
		//printf("11111%lf", mul_test(&Single_StorageA, &Single_StorageB, Total_Size));
		int temp_coord[2];
		double* storageA = (double*)malloc(sizeof(double) * Matrix_size[0] * Matrix_size[1]);
		double* storageB = (double*)malloc(sizeof(double) * Matrix_size[0] * Matrix_size[1]);
		int count = Nproc - 1;
		while (count > 0) {
			MPI_Recv(Buffer, buffersize, MPI_PACKED, MPI_ANY_SOURCE, DataMassage, Comm_World, &st);
			position = 0;
			MPI_Unpack(Buffer, buffersize, &position, temp_coord, 2, MPI_INT, Comm_World);
			MPI_Unpack(Buffer, buffersize, &position, storageA, Matrix_size[0] * Matrix_size[1], MPI_DOUBLE, Comm_World);
			MPI_Unpack(Buffer, buffersize, &position, storageB, Matrix_size[0] * Matrix_size[1], MPI_DOUBLE, Comm_World);
			if (!Check_sub_Matrix(storageA, storageB, temp_coord, Single_StorageA, Single_StorageB, Matrix_size)) {
				MPI_Abort(Comm_World, InitFalse);
			}
			else {
				printf("Check Sub-Matrix succeed in process %d\n", st.MPI_SOURCE);
			};
			count--;
		}
		if (Check_sub_Matrix(MatrixA_StoreBuffer, MatrixB_StoreBuffer, coord, Single_StorageA, Single_StorageB, Matrix_size)) {
			printf("Check Sub-Matrix succeed in process %d\n", 0);
		}
		free(Single_StorageA);
		free(Single_StorageB);
		free(storageA);
		free(storageB);
	}
	else {
		//����������ڴ�ȷ��һ�����ݽṹ���ڴ�����0���̽��жԱ�
		int Length[3];
		Length[0] = 2;//������
		Length[1] = Matrix_size[0] * Matrix_size[1];//��ô�����,�ȷ���A�ڷ�B
		Length[2] = Matrix_size[0] * Matrix_size[1];
		MPI_Aint DisplaceMent[3];
		MPI_Get_address(coord,&DisplaceMent[0]);
		MPI_Get_address(MatrixA_StoreBuffer, &DisplaceMent[1]);
		MPI_Get_address(MatrixB_StoreBuffer, &DisplaceMent[2]);
		MPI_Datatype ArrayType[3];
		ArrayType[0] = MPI_INT;
		ArrayType[1] = MPI_DOUBLE;
		ArrayType[2] = MPI_DOUBLE;
		MPI_Datatype Temp_type;
		MPI_Type_create_struct(3, Length, DisplaceMent, ArrayType, &Temp_type);
		MPI_Type_commit(&Temp_type);
		position = 0;
		MPI_Pack(MPI_BOTTOM, 1, Temp_type, Buffer, buffersize, &position, Comm_World);
		MPI_Send(Buffer, position, MPI_PACKED, 0, DataMassage, Comm_World);
		MPI_Type_free(&Temp_type);
	}
	free(Buffer);
	
}

double** CreatSingleThreadToCheckA(int* Matrix_Size,int* Total_Size) {
	double** Storage = (double**)malloc(sizeof(double*) * Total_Size[0]);
	//cout << endl;
	for (int i = 0; i < Total_Size[0]; i++) {
		Storage[i] = (double*)malloc(sizeof(double) * Total_Size[1]);
	}

	for (int i = 0; i < Total_Size[0]; i++) {
		for (int j = 0; j < Total_Size[1]; j++) {
			double x = (i - 1.0) / (Total_Size[0] - 1);
			double y = (j - 1.0) / (Total_Size[0] - 1);
			Storage[i][j]= exp(y) * sin(3.0 * x);
			//cout << Storage[i][j]<<"    ";
		}
		//cout << endl;
	}
	return Storage;
}

double** CreatSingleThreadToCheckB(int* Matrix_Size, int* Total_Size) {
	double** Storage = (double**)malloc(sizeof(double*) * Total_Size[0]);
	//cout << endl;
	for (int i = 0; i < Total_Size[0]; i++) {
		Storage[i] = (double*)malloc(sizeof(double) * Total_Size[1]);
	}
	for (int i = 0; i < Total_Size[0]; i++) {
		for (int j = 0; j < Total_Size[1]; j++) {
			double x = (i - 1.0) / (Total_Size[0] - 1);
			double y = (j - 1.0) / (Total_Size[0] - 1);
			Storage[i][j] = (x + cos(4.0 * x)) * (1 + y);
			//cout << Storage[i][j] << "  ";
		}
		//cout << endl;
	}
	return Storage;
}

bool Check_sub_Matrix(double* Init_A,double* Init_B,int* coord,double** corr_A,double** coor_B,int* matrix_size) {
	//check A
	printf("\n");
	int RowBegin = coord[0] * matrix_size[0];
	int ColBegin = coord[1] * matrix_size[1];
	int count = 0;
	for (int i = RowBegin; i < RowBegin + matrix_size[0]; i++) {
		for (int j = ColBegin; j < ColBegin + matrix_size[1]; j++) {
			if (Init_A[count++] != corr_A[i][j]) {
				return false;
			}
		}
	}
	//check B
	count = 0;
	for (int j = ColBegin; j < ColBegin + matrix_size[1]; j++) {
		for (int i = RowBegin; i < RowBegin + matrix_size[0]; i++) {
			if (Init_B[count++] != coor_B[i][j]) {
				return false;
			}
		}
	}
	return true;
}

double Matrix_Mult_Canno
(	MPI_Comm Comm_World, 
	double** MatrixA_StoreBuffer, double** MatrixB_StoreBuffer,
	int* Matrix_Size, int* Total_Size,int* dim
) 
{
	double Result = 0;
	int id;
	int Nproc;
	MPI_Status st;
	MPI_Comm_rank(Comm_World,&id);
	MPI_Comm_size(Comm_World, &Nproc);
	int Runtime = sqrt(Nproc);
	int proc = sqrt(Nproc);
	int coord[2];
	int Temp_id1;
	int Temp_coord1[2];
	int Temp_id2;
	int Temp_coord2[2];
	MPI_Cart_coords(Comm_World, id, 2, coord);
	
	//To hold the matrix transport from other process,if using mpi_sendrecv rather than mpi_sr_relaplace
	//double* MatrixA_ReceiveBuffer = (double*)malloc(sizeof(double) * Matrix_Size[0] * Matrix_Size[1]);
	//double* MatrixB_ReceiveBuffer = (double*)malloc(sizeof(double) * Matrix_Size[0] * Matrix_Size[1]);
	double* MatrixC_Result_Buffer = (double*)malloc(sizeof(double) * Matrix_Size[0] * Matrix_Size[1]);
	memset(MatrixC_Result_Buffer, 0, sizeof(double) * Matrix_Size[0] * Matrix_Size[1]);
		//printf("%d,from [%d,%d]\n", id,coord[0],coord[1]);
	double Target_CC = 0;
	//the Following part is to transport sub matrix to another thread, the direction shoud be like flow
	//sub matrix A to the left side, for example in process number 2*2 , the (0,0)->(0,1), (1,1)->(0,1)
	//for matrix B to the upper side, like (1,1)->(0,1),(1,0)->(0,0),(0,0)->(1,0)
	//-------------alliment----------------
	int tt = coord[0];
	while (tt > 0) {
		Temp_coord1[0] = coord[0];
		Temp_coord1[1] = ((coord[1] - 1) + proc) % (proc);//runtime==sqrt(nproc),eg: 6*6 
		//(0,0)->(0,((0-1)+6)%6)->(0,5)
		MPI_Cart_rank(Comm_World, Temp_coord1, &Temp_id1);
		//recev from
		Temp_coord2[0] = coord[0];
		Temp_coord2[1] = (coord[1] + 1) % (proc);//(0,0)->(0,(0+1)%6)->(0,1);(5,5)->(5,(5+1)%6)->(5,0)
		MPI_Cart_rank(Comm_World, Temp_coord2, &Temp_id2);

		MPI_Sendrecv_replace(*MatrixA_StoreBuffer, Matrix_Size[0] * Matrix_Size[1], MPI_DOUBLE,
			Temp_id1, MatrixA, Temp_id2, MatrixA, Comm_World, &st);
		tt--;
	}
	tt = coord[1];
	while (tt > 0) {
		Temp_coord1[0] = (coord[0] - 1 + proc) % (proc);
		Temp_coord1[1] = coord[1];
		MPI_Cart_rank(Comm_World, Temp_coord1, &Temp_id1);
		//recev from
		Temp_coord2[0] = (coord[0] + 1) % (proc);
		Temp_coord2[1] = coord[1];
		MPI_Cart_rank(Comm_World, Temp_coord2, &Temp_id2);
		MPI_Sendrecv_replace(*MatrixB_StoreBuffer, Matrix_Size[0] * Matrix_Size[1], MPI_DOUBLE,
			Temp_id1, MatrixB, Temp_id2, MatrixB, Comm_World, &st);
		tt--;
	}
	while (Runtime > 0) {
		//if (id == 1)
		//	cout << endl;
		for (int i = 0; i < Matrix_Size[0]; i++) {
			for (int j = 0; j < Matrix_Size[1]; j++) {	
				for (int k = 0; k < Matrix_Size[0]; k++) {
					//sub matrix mult;
				//if (id == 1) {
				//	cout << (*MatrixA_StoreBuffer)[i * Matrix_Size[0] + k]<<"   aa "<<endl;
					//cout << (*MatrixB_StoreBuffer)[j * Matrix_Size[0] + k] << "   aa ";
				//}
					MatrixC_Result_Buffer[i * Matrix_Size[0] + j] +=
						(
							(*MatrixA_StoreBuffer)[i * Matrix_Size[0] + k] *
							(*MatrixB_StoreBuffer)[j * Matrix_Size[0] + k]
						);
				}
			}
			//if(id == 1)
			//cout << endl;
		}
		//------------------- SEND A TO NEXT ------------------- 
		//send to 
		Temp_coord1[0] = coord[0];
		Temp_coord1[1] = ((coord[1] - 1) + proc) % (proc);//runtime==sqrt(nproc),eg: 6*6 
		//(0,0)->(0,((0-1)+6)%6)->(0,5)
		MPI_Cart_rank(Comm_World, Temp_coord1, &Temp_id1);
		//recev from
		Temp_coord2[0] = coord[0];
		Temp_coord2[1] = (coord[1] + 1) % (proc);//(0,0)->(0,(0+1)%6)->(0,1);(5,5)->(5,(5+1)%6)->(5,0)
		MPI_Cart_rank(Comm_World, Temp_coord2, &Temp_id2);
		
		MPI_Sendrecv_replace(*MatrixA_StoreBuffer, Matrix_Size[0] * Matrix_Size[1],MPI_DOUBLE,
							  Temp_id1, MatrixA,Temp_id2, MatrixA, Comm_World, &st);
		//printf("Arecev from(%d,%d),send to(%d,%d),for process: %d\n", Temp_coord2[0], Temp_coord2[1], Temp_coord1[0], Temp_coord1[1], id);
		
		//------------------- SEND B TO NEXT ------------------- 
		//send to 
		Temp_coord1[0] = (coord[0] - 1 + proc) % (proc);
		Temp_coord1[1] =  coord[1];
		MPI_Cart_rank(Comm_World, Temp_coord1, &Temp_id1);
		//recev from
		Temp_coord2[0] = (coord[0] + 1) % (proc);
		Temp_coord2[1] =  coord[1];
		MPI_Cart_rank(Comm_World, Temp_coord2, &Temp_id2);
		MPI_Sendrecv_replace(*MatrixB_StoreBuffer, Matrix_Size[0] * Matrix_Size[1], MPI_DOUBLE,
							  Temp_id1, MatrixB, Temp_id2, MatrixB, Comm_World, &st);
		//printf("Brecev from(%d,%d),send to(%d,%d),for process: %d\n", Temp_coord2[0], Temp_coord2[1], Temp_coord1[0], Temp_coord1[1], id);
		Runtime--;
	}

	//printf("%lf\n from process %d", MatrixC_Result_Buffer[3], id);
	for (int i = 0; i < Matrix_Size[0]* Matrix_Size[1]; i++) {
		Target_CC += MatrixC_Result_Buffer[i] * MatrixC_Result_Buffer[i];
	}
	//printf("%lf from process %d\n", Target_CC / (Total_Size[0] * Total_Size[0]),id);
	//printf("%lf\n from process %d", Target_CC, id);
	MPI_Reduce(&Target_CC, &Result, 1, MPI_DOUBLE, MPI_SUM, 0, Comm_World);
	return Result;
}

double Res_check(int* Matrix_size) {
	int row = Matrix_size[0];
	int col = Matrix_size[1];

	double** A = (double**)malloc(sizeof(double*) * row);
	for (int i = 0; i < row; i++) {
		A[i] = (double*)malloc(sizeof(double) * col);
	}
	double** B = (double**)malloc(sizeof(double*) * row);
	for (int i = 0; i < row; i++) {
		B[i] = (double*)malloc(sizeof(double) * col);
	}

	double** C = (double**)malloc(sizeof(double*) * row);
	for (int i = 0; i < row; i++) {
		C[i] = (double*)malloc(sizeof(double) * col);
		memset(C[i], 0, sizeof(double) * col);
	}

	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			double x = (i - 1.0) / (row - 1);
			double y = (j - 1.0) / (row - 1);
			A[i][j] = exp(y) * sin(3.0 * x);
			B[i][j] = (x + cos(4.0 * x)) * (1 + y);
		}
	}
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			for (int k = 0; k < row; k++) {
				C[i][j] += A[i][k] * B[k][j];
			}
		}
	}
	double res = 0;
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			res += C[i][j] * C[i][j];
		}
	}
	res /= (row * row);
	return res;
}

double mul_test(double*** A, double*** B,int* Total_Size) {
	double** C = (double**)malloc(sizeof(double*) * Total_Size[0]);
	for (int i = 0; i < Total_Size[0]; i++) {
		C[i] = (double*)malloc(sizeof(double) * Total_Size[1]);
		memset(C[i], 0, sizeof(double) * Total_Size[1]);
	}
	double res = 0;
	for (int i = 0; i < Total_Size[0]; i++) {
		for (int j = 0; j < Total_Size[1]; j++) {
			for (int k = 0; k < Total_Size[0]; k++) {
				C[i][j] += (* A) [i][k] * (*B)[k][j];
			}
		}
	}
	for (int i = 0; i < Total_Size[0]; i++) {
		for (int j = 0; j < Total_Size[1]; j++) {
			res += C[i][j] * C[i][j];
		}
	}
	res /= (Total_Size[1]* Total_Size[1]);
	return res;
}