#include "Helpfunc.h"
#include <iostream>
using namespace std;
long Cal_sum(int& Till) {
	int id;
	int Nproc;
	MPI_Comm_rank(MPI_COMM_WORLD,&id);
	MPI_Comm_size(MPI_COMM_WORLD,&Nproc);
	long  res = 0;
	long Abuffer = 0;
	for (long i = id; i <= Till;i+=Nproc) {
		res = res+i;
	}
	MPI_Reduce(&res, &Abuffer, 1, MPI_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
	return Abuffer;
}