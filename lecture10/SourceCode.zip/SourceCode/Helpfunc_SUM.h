#pragma once
#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
//--------------------------------Massage Type-----------------------------------------------------
#define InitFalse 0
#define DataMassage 1
#define CheckFasle 2

//--------------------------------Buffer Init Function-----------------------------------------------------


//--------------------------------Calculation Function-----------------------------------------------------
long Cal_sum(int& Till);
//--------------------------------Check Function-----------------------------------------------------
