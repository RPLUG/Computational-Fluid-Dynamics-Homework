﻿#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include "Helpfunc.h"
#include <time.h>
int main(int argc, char* argv[]) {
	int Nproc;
	int id;
	int Row = 10000;
	int Col = 10000; 
	MPI_Comm Comm2D;
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &Nproc);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	int dim[2];
	dim[0] = sqrt(Nproc);
	dim[1] = sqrt(Nproc);

	int Matrix_size[2];
	Matrix_size[0] = Row / dim[0];
	Matrix_size[1] = Col / dim[1];

	int Total_size[2];
	Total_size[0] = Row;
	Total_size[1] = Col;

	int periods[2];
	periods[0] = 0;
	periods[1] = 0;

	MPI_Cart_create(MPI_COMM_WORLD, 2, dim, periods, 0, &Comm2D);
	
	double* MatrixA_StoreBuffer = NULL;
	double* MatrixB_StoreBuffer = NULL;

	Init_val_generate(Comm2D, dim,Matrix_size, &MatrixA_StoreBuffer, &MatrixB_StoreBuffer,Total_size);
	//printf("%lf", MatrixA_StoreBuffer[5]);
	MPI_Barrier(Comm2D);
	double t1=MPI_Wtime();
	double RES = Matrix_Mult_Canno(Comm2D, &MatrixA_StoreBuffer, &MatrixB_StoreBuffer, Matrix_size, Total_size, dim);
	double t2 = MPI_Wtime();
	

	if (id == 0) {
		RES /= (Total_size[0] * Total_size[1]);
		double c1 = clock();
		//double sigres =  Res_check(Total_size);
		double c2 = clock();
		//printf("The final result is %lf, single thread result is %lf\n", RES, sigres);
		printf("MPI %d proc time %lf\n",Nproc, t2 - t1);
		//printf("one Cpu time %lf\n", (c2 - c1)/CLOCKS_PER_SEC);
	}
	fflush(stdout);

	MPI_Finalize();
	return 0;
}