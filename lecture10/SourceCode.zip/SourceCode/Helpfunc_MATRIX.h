#pragma once
#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
//--------------------------------Massage Type-----------------------------------------------------
#define InitFalse 0
#define DataMassage 1
#define CheckFasle 2
#define MatrixA 3
#define MatrixB 4
//--------------------------------Buffer Init Function-----------------------------------------------------
void Init_val_generate(MPI_Comm Comm2D, int* dim,int* Matrix_Size,
	double** MatrixA_StoreBuffer,double** MatrixB_StoreBuffer,int* Total_size);

//--------------------------------Calculation Function-----------------------------------------------------
double Matrix_Mult_Canno(MPI_Comm Comm_World, double** MatrixA_StoreBuffer, double** MatrixB_StoreBuffer,
						int* Matrix_size, int* Total_size, int* dim);
double Res_check(int* Total_Size);
//--------------------------------Check Function-----------------------------------------------------
void Init_Check(MPI_Comm Comm_World,double* MatrixA_StoreBuffer,double* MatrixB_StoreBuffer,int* Matrix_size,int* Total_Size);

double** CreatSingleThreadToCheckA(int* Matrix_size, int* Total_Size);

double** CreatSingleThreadToCheckB(int* Matrix_size, int* Total_Size);

bool Check_sub_Matrix(double* Init_A, double* Init_B, int* coord, double** corr_A, double** coor_B,int* Matrix_size);

double mul_test(double*** A, double*** B, int* Total_Size);