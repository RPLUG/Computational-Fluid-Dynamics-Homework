﻿#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include "Helpfunc.h"
#include <time.h>
int main(int argc, char* argv[]) {
	int Nproc;
	int id;
	int till = 1000;
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &Nproc);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	long res = Cal_sum(till);
	if (id == 0) {
		printf("%ld", res);
	}
	MPI_Finalize();
	return 0;
}