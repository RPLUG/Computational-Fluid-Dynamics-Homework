#include <iostream>
#include "Calcu.h"
#include <utility>
int main(){
    string path = GetCurrentPath();
    string outpath = path + "\\result.txt";
    int Mesh_Number = 100;
    double deltaX = (2 * 3.1415926) / Mesh_Number;
    double deltaT = 0.0001;
    int iterationtimes = 500;
    /*Already find the best solution as a6=-9.59 when deltax = 0.001*/
    vector<double> A6(3);
    A6[0] = -10;//begin
    A6[1] = 10;//end
    A6[2] = 0.01;//step
    
    pair<vector<KData>, double> st = Draw(A6,deltaX,outpath);
    result_out_put(outpath,st,deltaX);

    Solution X(st,deltaX,deltaT,iterationtimes,Mesh_Number);
    X.Getpara();
    X.ExtractSolINIT();
    
    X.loop();
    
    return 0;
}